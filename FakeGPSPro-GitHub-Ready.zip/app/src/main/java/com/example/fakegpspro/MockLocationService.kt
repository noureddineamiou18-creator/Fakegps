package com.example.fakegpspro

import android.app.*
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class MockLocationService : Service() {
    companion object {
        const val ACTION_START = "com.example.fakegpspro.START"
        const val ACTION_STOP = "com.example.fakegpspro.STOP"
        const val EXTRA_POINTS = "points"
        private const val CHANNEL = "fake_gps_channel"
        private const val NOTIFICATION_ID = 42
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "GPS simulation", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            job?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Fake GPS Pro")
            .setContentText("محاكاة الموقع قيد التشغيل")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).build())

        @Suppress("DEPRECATION")
        val points = intent?.getParcelableArrayListExtra<Location>(EXTRA_POINTS) ?: arrayListOf()
        if (points.isNotEmpty()) {
            job?.cancel()
            job = scope.launch {
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                try {
                    lm.addTestProvider(
                        LocationManager.GPS_PROVIDER, false, false, false, false,
                        true, true, true, 0, 5
                    )
                } catch (_: IllegalArgumentException) { /* provider already exists */ }
                try { lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true) } catch (_: Exception) { }
                while (isActive) {
                    for (point in points) {
                        if (!isActive) break
                        val loc = Location(LocationManager.GPS_PROVIDER).apply {
                            latitude = point.latitude
                            longitude = point.longitude
                            accuracy = 5f
                            time = System.currentTimeMillis()
                            elapsedRealtimeNanos = android.os.SystemClock.elapsedRealtimeNanos()
                        }
                        try { lm.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc) } catch (_: SecurityException) { }
                        delay(1000)
                    }
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
