package com.example.fakegpspro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            // Deliberately does not auto-start spoofing: user must explicitly enable a saved route.
            // Add an opt-in saved-route resume flow only after validating permissions and Android restrictions.
        }
    }
}
