package com.example.fakegpspro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.events.MapEventsReceiver

data class RoutePoint(
    val lat: Double,
    val lon: Double
)

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {

    private var mapView: MapView? = null

    private val locationPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { }

    private val notificationPermission =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().userAgentValue =
            "FakeGPSPro/2.0 (com.example.fakegpspro)"

        setContent {
            MaterialTheme {
                var lat by remember { mutableDoubleStateOf(36.7538) }
                var lon by remember { mutableDoubleStateOf(3.0588) }
                var showSettings by remember { mutableStateOf(false) }
                var showPoints by remember { mutableStateOf(false) }

                val points = remember {
                    mutableStateListOf<RoutePoint>()
                }

                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("Fake GPS Pro") },
                            actions = {
                                IconButton(
                                    onClick = { showSettings = true }
                                ) {
                                    Text("⚙")
                                }
                            }
                        )
                    }
                ) { padding ->

                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(padding)
                    ) {

                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { context ->
                                MapView(context).apply {
                                    setTileSource(TileSourceFactory.MAPNIK)
                                    setMultiTouchControls(true)
                                    controller.setZoom(6.0)
                                    controller.setCenter(
                                        GeoPoint(lat, lon)
                                    )

                                    overlays.add(
                                        MapEventsOverlay(
                                            object : MapEventsReceiver {
                                                override fun
                                                    singleTapConfirmedHelper(
                                                        point: GeoPoint
                                                    ): Boolean {
                                                    lat = point.latitude
                                                    lon = point.longitude
                                                    invalidate()
                                                    return true
                                                }

                                                override fun
                                                    longPressHelper(
                                                        point: GeoPoint
                                                    ): Boolean = false
                                            }
                                        )
                                    )

                                    mapView = this
                                }
                            },
                            update = { map ->
                                map.overlays
                                    .filterIsInstance<Marker>()
                                    .forEach {
                                        map.overlays.remove(it)
                                    }

                                map.overlays.add(
                                    Marker(map).apply {
                                        position = GeoPoint(lat, lon)
                                        title = "الموقع المحدد"
                                        setAnchor(
                                            Marker.ANCHOR_CENTER,
                                            Marker.ANCHOR_BOTTOM
                                        )
                                    }
                                )

                                map.invalidate()
                            }
                        )

                        Column(
                            Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .padding(10.dp)
                        ) {
                            Card {
                                Column(
                                    Modifier.padding(12.dp)
                                ) {
                                    Text(
                                        "الموقع المختار",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text("Latitude: %.6f".format(lat))
                                    Text("Longitude: %.6f".format(lon))
                                }
                            }
                        }

                        Column(
                            Modifier
                                .align(Alignment.CenterEnd)
                                .padding(10.dp),
                            verticalArrangement =
                                Arrangement.spacedBy(8.dp)
                        ) {
                            FloatingActionButton(
                                onClick = {
                                    mapView?.controller?.zoomIn()
                                }
                            ) {
                                Text("+")
                            }

                            FloatingActionButton(
                                onClick = {
                                    mapView?.controller?.zoomOut()
                                }
                            ) {
                                Text("−")
                            }
                        }

                        Card(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(10.dp)
                        ) {
                            Column(
                                Modifier.padding(12.dp),
                                verticalArrangement =
                                    Arrangement.spacedBy(8.dp)
                            ) {
                                Text("نقاط المسار: ${points.size}")

                                Row(
                                    horizontalArrangement =
                                        Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            points.add(
                                                RoutePoint(lat, lon)
                                            )
                                        }
                                    ) {
                                        Text("إضافة نقطة")
                                    }

                                    OutlinedButton(
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            showPoints = true
                                        }
                                    ) {
                                        Text("عرض النقاط")
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        showSettings = true
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("الإعدادات والصلاحيات")
                                }
                            }
                        }
                    }
                }

                if (showSettings) {
                    AlertDialog(
                        onDismissRequest = {
                            showSettings = false
                        },
                        title = { Text("الإعدادات والصلاحيات") },
                        text = {
                            Column(
                                verticalArrangement =
                                    Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        locationPermission.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("صلاحيات الموقع")
                                }

                                Button(
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= 33) {
                                            notificationPermission.launch(
                                                Manifest.permission.POST_NOTIFICATIONS
                                            )
                                        } else {
                                            startActivity(
                                                Intent(
                                                    Settings.ACTION_APP_NOTIFICATION_SETTINGS
                                                ).putExtra(
                                                    Settings.EXTRA_APP_PACKAGE,
                                                    packageName
                                                )
                                            )
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("صلاحية الإشعارات")
                                }

                                Button(
                                    onClick = {
                                        startActivity(
                                            Intent(
                                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                Uri.parse("package:$packageName")
                                            )
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("إعدادات التطبيق")
                                }

                                Button(
                                    onClick = {
                                        startActivity(
                                            Intent(
                                                Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
                                            )
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("خيارات المطوّر")
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    showSettings = false
                                }
                            ) {
                                Text("إغلاق")
                            }
                        }
                    )
                }

                if (showPoints) {
                    AlertDialog(
                        onDismissRequest = {
                            showPoints = false
                        },
                        title = {
                            Text("قائمة النقاط")
                        },
                        text = {
                            LazyColumn(
                                modifier = Modifier.heightIn(
                                    max = 350.dp
                                )
                            ) {
                                itemsIndexed(points) { index, point ->
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement =
                                            Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            "${index + 1}. " +
                                            "%.5f, %.5f".format(
                                                point.lat,
                                                point.lon
                                            )
                                        )

                                        TextButton(
                                            onClick = {
                                                points.removeAt(index)
                                            }
                                        ) {
                                            Text("حذف")
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    showPoints = false
                                }
                            ) {
                                Text("إغلاق")
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mapView?.onResume()
    }

    override fun onPause() {
        mapView?.onPause()
        super.onPause()
    }
}
